flameRed = {
  'hex': '#d23527',
  'name': 'Red',
  'sz': 0.5,
  'alpha': 1.0,
}

flameOrange = {
  'hex': '#f6802b',
  'name': 'Orange',
  'sz': 0.5,
  'alpha': 0.75,
}

emerald = {
  'hex': '#37B151',
  'name': 'Emerald',
  'sz': 0.5,
  'alpha': 0.85,
}

sapGreen = {
  'hex': '#1f7231',
  'name': 'Sap Green',
  'sz': 0.5,
  'alpha': 0.5,
}

cyan = {
  'hex': '#159BD7',
  'name': 'Cyan',
  'sz': 0.5,
  'alpha': 0.8,
}

rowneyBlue = {
  'hex': '#136cc6',
  'name': 'Blue',
  'sz': 0.5,
  'alpha': 0.8,
}

magenta = {
  'hex': '#EB008A',
  'name': 'Magenta',
  'sz': 0.5,
  'alpha': 0.6,
}

black = {
  'hex': '#000000',
  'name': 'Black',
  'sz': 0.5,
  'alpha': 1.0,
}